<p align="center">
<img title="Autor" src="https://img.shields.io/badge/Autor-@tedzinho_-orange.svg?style=for-the-badge&logo=github"></a>
<img title="Versão" src="https://img.shields.io/badge/Versão-0.0.1-orange.svg?style=for-the-badge&logo=github"></a>
</p>

## Instalação Via Termux  <img src="https://user-images.githubusercontent.com/108157095/182052725-6568419a-6a9f-490a-85ea-90b94af694fe.png" height="25px">
**1° Comando**
```
apt-get update -y && pkg upgrade -y && pkg update -y && pkg install nodejs -y && pkg install nodejs-lts -y && pkg install ffmpeg -y && pkg install wget -y && pkg install tesseract -y && pkg install git -y
```
**ATENÇÃO:**
Será necessário digitar y toda vez que pedir a caixa [y/n]
---------------------------

**2° Comando**
```
termux-setup-storage
```
**3° Comando**
```
cd /sdcard/Download && git clone https://github.com/Tedzinho/bot-zero
```
**4° Comando**
```
cd /sdcard/Download/bot-zero && npm start
```

## 💾 START DO BOT 💾 <img src="https://user-images.githubusercontent.com/108157095/182053901-78e4a217-51ba-42a3-8ec5-38ed978ad752.png" height="25px">
```
npm start
```